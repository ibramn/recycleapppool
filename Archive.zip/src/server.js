const express = require('express');
const path = require('path');
const iis = require('node-iis');

const app = express();
const port = 3000;

// Serve static files
app.use(express.static('public'));

// API endpoint to recycle app pool
app.post('/api/recycle-pool', async (req, res) => {
    try {
        // Replace 'YourAppPoolName' with your actual app pool name
        await iis.recycleAppPool('portal.englishawy.net');
        res.json({ success: true, message: 'Application pool recycled successfully' });
    } catch (error) {
        console.error('Error recycling app pool:', error);
        res.status(500).json({ success: false, message: 'Failed to recycle application pool '+error.message });
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
}); 